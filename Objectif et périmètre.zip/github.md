repo: momobijive2020/Sahara_Oil
branch: main

## Last sync

date: 2026-08-19T19:27:14Z

### Updated in this project

- Maquette haute-fidélité `Sahara Oil Trading.dc.html` recréée à partir de `content.py` / `templates/` / `static/css/style.css`.
- Nouvelles copies Services (domaines d'expertise, import, export) non encore commitées en amont.
- Adresse siège social (556 Rue Koumassi-Bali, B.P. 4736 Douala) et téléphones (+237 672 77 99 50 / 622 12 79 57) mis à jour.
- Marchés desservis réduits à Cameroun, Tchad, RCA ; bascule FR/EN automatique ajoutée.

## Screen map

| Écran du projet | Fichiers du dépôt |
|---|---|
| Sahara Oil Trading.dc.html (site complet 1 page) | content.py, templates/base.html, templates/index.html, static/css/style.css, static/js/script.js |
| assets/ (logo, hero, distribution, tanker, pipeline) | static/img/*.jpg |
