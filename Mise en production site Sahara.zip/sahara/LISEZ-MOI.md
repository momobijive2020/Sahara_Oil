# Mise à jour du site Sahara — mode d'emploi

## 1. Copier les fichiers dans le repo

Depuis le dossier de ce paquet, écrase les fichiers du repo `Sahara_Oil` :

| Fichier du paquet | Destination dans le repo |
| --- | --- |
| `content.py` | `content.py` |
| `i18n.py` | `i18n.py` *(nouveau fichier)* |
| `app.py` | `app.py` |
| `templates/base.html` | `templates/base.html` |
| `templates/index.html` | `templates/index.html` |

## 2. Tester en local

```bash
pip install -r requirements.txt
python app.py
```

Ouvre http://127.0.0.1:5000 — puis clique sur **EN** dans la barre de navigation
pour vérifier la version anglaise.

## 3. Pousser en production

```bash
git add .
git commit -m "Contenu: expertise, coordonnées Douala, marchés; ajout traduction FR/EN"
git push
```

Render redéploie automatiquement (suivre l'onglet **Logs** du service `Sahara_Oil`).

---

## Ce qui a changé

**Contenu**
- Nouvelle section **« Nos Domaines d'Expertise »** (carburants, lubrifiants, bitume, GPL) avec le bouton « Découvrez nos solutions sur mesure », placée entre Services et Produits, ajoutée à la navigation et au pied de page.
- Textes **Importation**, **Exportation** et **Distribution Locale** remplacés par les nouveaux.
- **Adresse et Siège Social** : 556 Rue Koumassi-Bali, B.P. 4736 Douala (remplace « Yaoundé, Cameroun »).
- **Téléphones** : (+237) 672 77 99 50 et (+237) 622 12 79 57 — dans la section Contact et le pied de page.
- **Marchés desservis** : Gabon, Congo et Guinée Équatoriale supprimés ; reste Cameroun, RCA, Tchad. Libreville retiré du bandeau d'actualités.

**Traduction FR / EN automatique**
- Nouveau fichier `i18n.py` : dictionnaire de traduction + fonction récursive.
- `app.py` détecte la langue dans cet ordre : `?lang=en` → cookie → langue du navigateur → français ; le choix est mémorisé un an. Nouvelle route `/lang/<code>`.
- Sélecteur **FR | EN** dans la barre de navigation (styles en ligne, `style.css` non modifié).
- Le contenu reste rédigé en français dans `content.py` : la traduction s'applique au rendu. Une phrase absente du dictionnaire s'affiche en français au lieu de casser la page.
- Les libellés d'interface (boutons, titres de sections, formulaire) sont désormais dans `content.py` sous `UI` pour être traduisibles.

## À vérifier

- Le second numéro était noté « (+237) 62212 79 57 » ; il a été écrit **(+237) 622 12 79 57**. Corrige-le dans `content.py` (`CONTACT["phone_secondary"]`) si ce n'est pas exact.
- Pour ajouter ou corriger une traduction anglaise : une ligne dans `TRANSLATIONS` (`i18n.py`), la clé étant la phrase française exacte.
