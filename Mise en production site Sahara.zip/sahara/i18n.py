"""
SAHARA OIL TRADING S.A. — Traduction automatique FR → EN.

Principe : le contenu du site reste rédigé en français dans `content.py`.
Au moment du rendu, `translate()` parcourt récursivement les structures de
contenu et remplace chaque chaîne française par sa traduction anglaise si elle
existe dans TRANSLATIONS. Une chaîne inconnue (identifiant, nom de fichier,
SVG, emoji…) est laissée telle quelle : aucun risque de casser le site.

Aucun template à dupliquer, aucune dépendance externe.
"""

from __future__ import annotations

LANGUAGES = {"fr": "Français", "en": "English"}
DEFAULT_LANGUAGE = "fr"

TRANSLATIONS: dict[str, str] = {
    # ---- Identité / SEO ----
    "S.A. — Cameroun": "S.A. — Cameroon",
    "SAHARA OIL TRADING S.A. – Distribution & Commerce de Produits Pétroliers au Cameroun":
        "SAHARA OIL TRADING S.A. – Petroleum Products Distribution & Trading in Cameroon",
    "SAHARA OIL TRADING S.A. est une société camerounaise leader dans la distribution, l'importation et l'exportation de produits pétroliers. Fiabilité, excellence et expertise énergétique en Afrique Centrale.":
        "SAHARA OIL TRADING S.A. is a leading Cameroonian company in the distribution, import and export of petroleum products. Reliability, excellence and energy expertise across Central Africa.",
    "pétrole Cameroun, produits pétroliers, importation exportation huile, carburant Cameroun, SAHARA OIL TRADING":
        "oil Cameroon, petroleum products, oil import export, fuel Cameroon, SAHARA OIL TRADING",
    "Spécialiste en distribution, importation et exportation de produits pétroliers au Cameroun.":
        "Specialists in the distribution, import and export of petroleum products in Cameroon.",

    # ---- Contact ----
    "556 Rue Koumassi-Bali": "556 Koumassi-Bali Street",
    "B.P. 4736 Douala": "P.O. Box 4736 Douala",
    "Douala, Cameroun": "Douala, Cameroon",
    "Afrique Centrale": "Central Africa",
    "Lun–Ven: 08h00 – 18h00": "Mon–Fri: 8:00 AM – 6:00 PM",
    "Lun–Ven: 08h00–18h00": "Mon–Fri: 8:00 AM–6:00 PM",
    "Port de Douala, Cameroun": "Port of Douala, Cameroon",
    "Terminal Pétrolier": "Oil Terminal",
    "556 Rue Koumassi-Bali, B.P. 4736 Douala": "556 Koumassi-Bali Street, P.O. Box 4736 Douala",
    "Adresse et Siège Social": "Address & Head Office",
    "Siège Social": "Head Office",
    "Port Principal": "Main Port",

    # ---- Navigation ----
    "Accueil": "Home",
    "À Propos": "About",
    "Services": "Services",
    "Expertise": "Expertise",
    "Produits": "Products",
    "Politique QHSE-E": "QHSE-E Policy",
    "Chiffres Clés": "Key Figures",
    "Contact": "Contact",
    "Navigation": "Navigation",

    # ---- Hero ----
    "Entreprise Camerounaise de Confiance": "A Trusted Cameroonian Company",
    "L'Excellence au Service": "Excellence in the Service",
    "de l'Énergie": "of African",
    "Africaine": "Energy",
    "SAHARA OIL TRADING S.A. est votre partenaire stratégique pour la distribution, l'importation et l'exportation de produits pétroliers en Afrique Centrale. Fiabilité, sécurité et excellence opérationnelle.":
        "SAHARA OIL TRADING S.A. is your strategic partner for the distribution, import and export of petroleum products in Central Africa. Reliability, safety and operational excellence.",
    "Années d'Expérience": "Years of Experience",
    "Partenaires Actifs": "Active Partners",
    "Pays Desservis": "Countries Served",

    # ---- Ticker ----
    "🛢️ Distribution de carburant au Cameroun": "🛢️ Fuel distribution across Cameroon",
    "⚡ Approvisionnement fiable en produits pétroliers": "⚡ Reliable supply of petroleum products",
    "🌍 Exportation vers l'Afrique Centrale et de l'Ouest": "🌍 Exports to Central and West Africa",
    "🚢 Importation internationale de pétrole brut": "🚢 International crude oil imports",
    "🏆 Certification ISO & conformité internationale": "🏆 ISO certification & international compliance",
    "📊 Marchés: Douala · Yaoundé · N'Djamena · Bangui": "📊 Markets: Douala · Yaoundé · N'Djamena · Bangui",

    # ---- À propos ----
    "À Propos de Nous": "About Us",
    "Un Pilier Énergétique": "An Energy Pillar",
    "au Cœur de l'Afrique": "at the Heart of Africa",
    "Fondée au Cameroun, <strong>SAHARA OIL TRADING S.A.</strong> s'est imposée comme un acteur majeur du secteur des hydrocarbures en Afrique Centrale.":
        "Founded in Cameroon, <strong>SAHARA OIL TRADING S.A.</strong> has established itself as a major player in the Central African hydrocarbons sector.",
    "Notre société allie expertise locale et standards internationaux pour offrir des solutions énergétiques complètes et fiables. De l'importation à la distribution finale, nous maîtrisons toute la chaîne de valeur des produits pétroliers.":
        "Our company combines local expertise with international standards to deliver complete, reliable energy solutions. From import to final distribution, we master the entire petroleum value chain.",
    "Avec une équipe de professionnels chevronnés et une infrastructure logistique de pointe, nous garantissons des approvisionnements continus, sécurisés et conformes aux normes environnementales les plus strictes.":
        "With a team of seasoned professionals and state-of-the-art logistics infrastructure, we guarantee continuous, secure supply that meets the strictest environmental standards.",
    "Leader Régional": "Regional Leader",
    "Afrique Centrale & de l'Ouest": "Central & West Africa",
    "Conformité Réglementaire": "Regulatory Compliance",
    "Respect des normes camerounaises et internationales": "Compliance with Cameroonian and international standards",
    "Sécurité & Fiabilité": "Safety & Reliability",
    "Processus certifiés et infrastructure sécurisée": "Certified processes and secure infrastructure",
    "Réseau International": "International Network",
    "Partenariats solides avec fournisseurs mondiaux": "Strong partnerships with global suppliers",
    "Partenariat & Collaboration": "Partnership & Collaboration",

    # ---- Services ----
    "Distribution Locale": "Local Distribution",
    "Des solutions énergétiques adaptées à chaque secteur : carburants et dérivés de haute qualité pour propulser votre industrie, vos commerces et vos transports vers l'efficacité.":
        "Energy solutions tailored to every sector: high-quality fuels and derivatives to drive your industry, retail and transport operations towards greater efficiency.",
    "Importation": "Import",
    "Importation internationale de pointe. Des délais maîtrisés grâce à un écosystème de partenaires stratégiques, du local à l'international, pour une réactivité sans faille.":
        "Best-in-class international importing. Lead times kept under control through an ecosystem of strategic partners, from local to global, for flawless responsiveness.",
    "Exportation": "Export",
    "Une porte ouverte vers l'Afrique Centrale. Expertise douanière et maîtrise des documents d'export (nationaux & internationaux) pour des opérations fluides et sécurisées.":
        "A gateway to Central Africa. Customs expertise and full command of export documentation (national & international) for smooth, secure operations.",
    "⭐ Service Phare": "⭐ Flagship Service",
    "Distribution pétrolière": "Petroleum distribution",
    "Importation pétrolière": "Petroleum import",
    "Exportation pétrolière": "Petroleum export",
    "Gasoil & Essence": "Diesel & Gasoline",
    "Lubrifiants industriels": "Industrial lubricants",
    "Bitume & Asphalte": "Bitumen & Asphalt",
    "GPL (Gaz de pétrole liquéfié)": "LPG (Liquefied Petroleum Gas)",
    "Pétrole brut (Crude Oil)": "Crude oil",
    "Produits raffinés": "Refined products",
    "Conformité douanière": "Customs compliance",
    "Gestion des risques": "Risk management",
    "Afrique Centrale & Ouest": "Central & West Africa",
    "Transport multimodal": "Multimodal transport",
    "Documentation internationale": "International documentation",
    "Assurance & traçabilité": "Insurance & traceability",

    # ---- Expertise ----
    "Nos Savoir-Faire": "Our Capabilities",
    "Nos Domaines": "Our Areas",
    "d'Expertise": "of Expertise",
    "Quatre filières maîtrisées de bout en bout, du carburant routier au gaz domestique.":
        "Four value chains mastered end to end, from road fuel to domestic gas.",
    "Découvrez nos solutions sur mesure": "Discover our tailor-made solutions",
    "Carburants pour tous les moteurs": "Fuels for every engine",
    "Essence et Diesel de haute qualité.": "High-quality Gasoline and Diesel.",
    "Solutions industrielles": "Industrial solutions",
    "Lubrifiants performants pour vos équipements.": "High-performance lubricants for your equipment.",
    "Infrastructures & Bâtiment": "Infrastructure & Construction",
    "Bitume pour vos chantiers.": "Bitumen for your worksites.",
    "Énergie domestique": "Domestic energy",
    "Gaz de Pétrole Liquéfié (GPL) pour vos besoins quotidiens.":
        "Liquefied Petroleum Gas (LPG) for your everyday needs.",

    # ---- Produits ----
    "Gasoil / Diesel": "Gas Oil / Diesel",
    "Carburant haute performance pour transport, industrie et agriculture. Conforme aux normes EU.":
        "High-performance fuel for transport, industry and agriculture. EU-standard compliant.",
    "Transport": "Transport",
    "Industrie": "Industry",
    "Agriculture": "Agriculture",
    "Essence Super": "Super Gasoline",
    "Essence sans plomb premium pour véhicules légers et motocycles. Qualité certifiée.":
        "Premium unleaded gasoline for light vehicles and motorcycles. Certified quality.",
    "Automobile": "Automotive",
    "Premium": "Premium",
    "Fuel Oil": "Fuel Oil",
    "Combustible lourd pour installations industrielles, centrales thermiques et bateaux.":
        "Heavy fuel for industrial plants, thermal power stations and vessels.",
    "Industrie lourde": "Heavy industry",
    "Maritime": "Marine",
    "Jet A-1 (Kérosène)": "Jet A-1 (Kerosene)",
    "Carburant aviation de haute pureté pour compagnies aériennes et aéroports.":
        "High-purity aviation fuel for airlines and airports.",
    "Aviation": "Aviation",
    "Haute Pureté": "High Purity",
    "Lubrifiants": "Lubricants",
    "Gamme complète d'huiles moteurs, graisses industrielles et fluides hydrauliques.":
        "Full range of engine oils, industrial greases and hydraulic fluids.",
    "Moteurs": "Engines",
    "Hydraulique": "Hydraulics",
    "Industriel": "Industrial",
    "GPL / Butane": "LPG / Butane",
    "Gaz de pétrole liquéfié pour usage domestique et industriel. Bouteilles et vrac.":
        "Liquefied petroleum gas for domestic and industrial use. Cylinders and bulk.",
    "Domestique": "Domestic",
    "Vrac": "Bulk",
    "Bitume": "Bitumen",
    "Bitume routier et industriel pour construction d'infrastructures et revêtement.":
        "Road and industrial bitumen for infrastructure construction and surfacing.",
    "BTP": "Construction",
    "Routier": "Road",
    "Pétrole Brut": "Crude Oil",
    "Pétrole brut léger et lourd pour raffineries et trading international.":
        "Light and heavy crude oil for refineries and international trading.",
    "Trading": "Trading",
    "Raffinage": "Refining",
    "International": "International",
    "Carburants": "Fuels",

    # ---- Chiffres clés ----
    "Au service du secteur pétrolier camerounais": "Serving Cameroon's petroleum sector",
    "Litres Distribués / An": "Litres Distributed / Year",
    "Volume annuel de produits pétroliers distribués": "Annual volume of petroleum products distributed",
    "Fournisseurs et clients à travers le monde": "Suppliers and clients worldwide",
    "Présence commerciale en Afrique et dans le monde": "Commercial presence in Africa and worldwide",

    # ---- QHSE ----
    "Société camerounaise spécialisée dans la distribution, l'importation et l'exportation de produits pétroliers, consciente des enjeux stratégiques, environnementaux et humains inhérents à ses activités, la Direction Générale s'engage à conduire l'ensemble de ses opérations en stricte conformité avec les principes suivants, applicables à tous les employés, sous-traitants, fournisseurs et partenaires de la société.":
        "As a Cameroonian company specialised in the distribution, import and export of petroleum products, and mindful of the strategic, environmental and human stakes inherent to its activities, Executive Management commits to conducting all of its operations in strict compliance with the following principles, applicable to all employees, subcontractors, suppliers and partners of the company.",
    "🏅 Politique approuvée par la Direction Générale": "🏅 Policy approved by Executive Management",
    "📋 Affichée sur les locaux & annexée aux appels d'offres": "📋 Displayed on site & attached to tender documents",
    "🔄 Révisée périodiquement": "🔄 Reviewed periodically",
    "Qualité": "Quality",
    "Garantir à nos clients des produits pétroliers conformes aux normes nationales et internationales applicables, avec un service fiable et une traçabilité rigoureuse à chaque étape de la chaîne d'approvisionnement, de la collecte jusqu'à la livraison finale.":
        "Guaranteeing our clients petroleum products that comply with applicable national and international standards, with reliable service and rigorous traceability at every stage of the supply chain, from collection through to final delivery.",
    "ISO Standards": "ISO Standards",
    "Traçabilité Totale": "Full Traceability",
    "Santé & Sécurité": "Health & Safety",
    "Protéger la santé et la sécurité de nos employés, sous-traitants et communautés riveraines par l'application stricte des procédures HSE, la formation continue du personnel et le contrôle efficace des risques liés au stockage, au transport et à la manutention des produits pétroliers.":
        "Protecting the health and safety of our employees, subcontractors and neighbouring communities through strict application of HSE procedures, ongoing staff training and effective control of risks related to the storage, transport and handling of petroleum products.",
    "Procédures HSE": "HSE Procedures",
    "Formation Continue": "Continuous Training",
    "Environnement": "Environment",
    "Minimiser l'impact environnemental de nos activités en prévenant la pollution, en gérant les déchets et rejets de manière responsable, et en respectant les réglementations environnementales applicables au secteur pétrolier au Cameroun et dans la sous-région.":
        "Minimising the environmental impact of our activities by preventing pollution, managing waste and discharges responsibly, and complying with the environmental regulations applicable to the petroleum sector in Cameroon and the sub-region.",
    "Prévention Pollution": "Pollution Prevention",
    "Gestion Déchets": "Waste Management",
    "Éthique & Intégrité": "Ethics & Integrity",
    "Conduire nos activités avec transparence, équité et intégrité. SAHARA OIL TRADING S.A. applique une politique de tolérance zéro envers la corruption, la fraude et toute forme de pratique commerciale déloyale, conformément à la législation camerounaise et aux standards internationaux.":
        "Conducting our business with transparency, fairness and integrity. SAHARA OIL TRADING S.A. applies a zero-tolerance policy towards corruption, fraud and any form of unfair commercial practice, in accordance with Cameroonian law and international standards.",
    "Tolérance Zéro Corruption": "Zero Tolerance for Corruption",
    "Conformité Légale": "Legal Compliance",
    "Engagements Contractuels": "Contractual Commitments",
    "Respecter scrupuleusement les délais, volumes et conditions convenus avec nos clients et partenaires, et maintenir une communication transparente tout au long de l'exécution de chaque contrat.":
        "Scrupulously honouring the deadlines, volumes and terms agreed with our clients and partners, and maintaining transparent communication throughout the performance of every contract.",
    "Délais Garantis": "Guaranteed Lead Times",
    "Communication Transparente": "Transparent Communication",
    "Responsabilité Sociale": "Social Responsibility",
    "Contribuer au développement économique local, favoriser l'emploi et la formation des talents nationaux, et entretenir des relations respectueuses avec les communautés locales et les autorités.":
        "Contributing to local economic development, promoting employment and the training of national talent, and maintaining respectful relations with local communities and authorities.",
    "Emploi Local": "Local Employment",
    "Développement National": "National Development",
    "Amélioration Continue": "Continuous Improvement",
    "Mesurer régulièrement la performance de ses activités au regard de ces engagements et mettre en œuvre les actions correctives nécessaires pour réaliser une amélioration continue.":
        "Regularly measuring the performance of its activities against these commitments and implementing the corrective actions needed to achieve continuous improvement.",
    "Audits Réguliers": "Regular Audits",
    "Actions Correctives": "Corrective Actions",
    "Politique disponible sur demande": "Policy available on request",
    "Cette politique est communiquée à tout le personnel, affichée dans les locaux de l'entreprise, annexée aux dossiers d'appels d'offres et mise à disposition de nos clients et partenaires.":
        "This policy is communicated to all staff, displayed on company premises, attached to tender files and made available to our clients and partners.",
    "Demander la Politique Complète": "Request the Full Policy",

    # ---- Pourquoi nous ----
    "Expertise Sectorielle": "Sector Expertise",
    "Plus de 15 ans d'expérience dans le secteur des hydrocarbures en Afrique Centrale. Une connaissance approfondie des marchés locaux et internationaux.":
        "Over 15 years of experience in the Central African hydrocarbons sector, with deep knowledge of local and international markets.",
    "Qualité Garantie": "Guaranteed Quality",
    "Tous nos produits sont soumis à des contrôles qualité rigoureux avant livraison. Conformité aux normes internationales ISO et aux réglementations locales.":
        "Every product undergoes rigorous quality control before delivery, in compliance with international ISO standards and local regulations.",
    "Logistique Optimisée": "Optimised Logistics",
    "Flotte de camions-citernes modernes, réseau de dépôts stratégiques et partenariats maritimes pour des livraisons ponctuelles et sécurisées.":
        "A modern tanker-truck fleet, a network of strategic depots and maritime partnerships for punctual, secure deliveries.",
    "Support 24/7": "24/7 Support",
    "Une équipe dédiée disponible à toute heure pour répondre à vos urgences d'approvisionnement et gérer vos commandes en temps réel.":
        "A dedicated team available around the clock to handle supply emergencies and manage your orders in real time.",
    "Prix Compétitifs": "Competitive Pricing",
    "Grâce à nos achats groupés et notre réseau international, nous offrons des prix compétitifs sans compromettre la qualité de nos produits.":
        "Thanks to bulk purchasing and our international network, we offer competitive prices without compromising product quality.",
    "Responsabilité Environnementale": "Environmental Responsibility",
    "Engagement fort pour des pratiques respectueuses de l'environnement, réduction des émissions et conformité aux normes écologiques internationales.":
        "A strong commitment to environmentally responsible practices, emission reduction and compliance with international ecological standards.",

    # ---- Contact / formulaire ----
    "Téléphone": "Phone",
    "Email": "Email",
    "🇨🇲 Cameroun": "🇨🇲 Cameroon",
    "🇨🇫 RCA": "🇨🇫 C.A.R.",
    "🇹🇩 Tchad": "🇹🇩 Chad",
    "Demande de Devis": "Request a Quote",
    "Partenariat": "Partnership",
    "Autre": "Other",

    # ---- Pied de page ----
    "Votre partenaire de confiance pour la distribution, l'importation et l'exportation de produits pétroliers en Afrique Centrale depuis plus de 15 ans.":
        "Your trusted partner for the distribution, import and export of petroleum products in Central Africa for over 15 years.",
    "Mentions Légales": "Legal Notice",
    "Politique de Confidentialité": "Privacy Policy",
    "CGV": "Terms of Sale",

    # ---- Libellés d'interface (UI) ----
    "Chargement en cours...": "Loading...",
    "Demander un Devis": "Request a Quote",
    "Menu": "Menu",
    "Retour en haut": "Back to top",
    "Contact Rapide": "Quick Contact",
    "Tous droits réservés.": "All rights reserved.",
    "Nos Services": "Our Services",
    "Nous Contacter": "Contact Us",
    "Défiler": "Scroll",
    "ACTUALITÉS": "NEWS",
    "Ce que nous faisons": "What We Do",
    "Nos": "Our",
    "Services Principaux": "Core Services",
    "De la source à la destination, nous couvrons l'intégralité de la chaîne d'approvisionnement en produits pétroliers.":
        "From source to destination, we cover the entire petroleum products supply chain.",
    "En savoir plus →": "Learn more →",
    "Notre Gamme": "Our Range",
    "Pétroliers": "Petroleum",
    "Une gamme complète de produits pétroliers pour tous vos besoins industriels, commerciaux et de transport.":
        "A complete range of petroleum products for all your industrial, commercial and transport needs.",
    "Notre Impact": "Our Impact",
    "Chiffres": "Key",
    "Clés": "Figures",
    "Des résultats qui témoignent de notre engagement et de notre expertise dans le secteur énergétique.":
        "Results that reflect our commitment and expertise in the energy sector.",
    "Engagement Officiel": "Official Commitment",
    "Politique": "Policy",
    "QHSE-E": "QHSE-E",
    "Qualité · Hygiène · Sécurité · Environnement · Éthique des Affaires":
        "Quality · Hygiene · Safety · Environment · Business Ethics",
    "Notre Avantage": "Our Advantage",
    "Pourquoi Choisir": "Why Choose",
    "Prenons Contact": "Get in Touch",
    "Contactez": "Contact",
    "Notre Équipe": "Our Team",
    "Notre équipe commerciale est disponible pour répondre à vos questions et élaborer des offres personnalisées.":
        "Our sales team is available to answer your questions and build tailored offers.",
    "Informations de Contact": "Contact Information",
    "Marchés Desservis": "Markets Served",
    "Envoyez-nous un Message": "Send Us a Message",
    "Prénom": "First Name",
    "Votre prénom": "Your first name",
    "Nom": "Last Name",
    "Votre nom": "Your last name",
    "Entreprise": "Company",
    "Nom de votre entreprise": "Your company name",
    "Type de Service": "Service Type",
    "Sélectionnez un service": "Select a service",
    "Message": "Message",
    "Décrivez votre besoin...": "Describe your needs...",
    "Ne pas remplir": "Do not fill in",
    "Envoyer le Message": "Send Message",
    "Votre message a été envoyé avec succès ! Notre équipe vous contactera sous 24h.":
        "Your message has been sent successfully! Our team will contact you within 24 hours.",
}


def normalize_lang(value: str | None) -> str:
    """Renvoie un code de langue valide ('fr' ou 'en')."""
    if value and value.lower()[:2] in LANGUAGES:
        return value.lower()[:2]
    return DEFAULT_LANGUAGE


def translate(value, lang: str = DEFAULT_LANGUAGE):
    """Traduit récursivement chaînes, listes, tuples et dictionnaires.

    Les clés de dictionnaire ne sont jamais traduites (elles servent
    d'identifiants côté template et côté formulaire).
    """
    if lang == DEFAULT_LANGUAGE:
        return value
    if isinstance(value, str):
        return TRANSLATIONS.get(value, value)
    if isinstance(value, list):
        return [translate(item, lang) for item in value]
    if isinstance(value, tuple):
        return tuple(translate(item, lang) for item in value)
    if isinstance(value, dict):
        return {key: translate(item, lang) for key, item in value.items()}
    return value
